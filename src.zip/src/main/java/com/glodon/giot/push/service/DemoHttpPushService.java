package com.glodon.giot.push.service;

import com.alibaba.fastjson.JSONObject;
import com.glodon.giot.push.entity.DeviceData;

import java.util.Map;

/**
 * Note
 * Author:liupz
 * Date:2020/10/28
 */
public class DemoHttpPushService implements IHTTPPushService {
    @Override
    public String getSN(String data) {
        return null;
    }

    @Override
    public DeviceData translate(String data) throws Exception {
        return null;
    }

    @Override
    public boolean auth(Map<String, String> headers, Map<String, String[]> params, JSONObject config) {
        return false;
    }
}
