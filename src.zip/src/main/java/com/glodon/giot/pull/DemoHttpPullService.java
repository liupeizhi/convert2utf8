package com.glodon.giot.pull;

import com.alibaba.fastjson.JSONObject;
import com.glodon.giot.channel.nodes.HttpResp;
import com.glodon.giot.common.security.MD5;
import com.glodon.giot.push.entity.DeviceData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Note
 * Author:liupz
 * Date:2020/10/13
 */
public class DemoHttpPullService implements IHTTPPullService {
    private final static Logger logger = LoggerFactory.getLogger(DemoHttpPullService.class);
    SystemFunction systemFunction;

    @Override
    public void beforeTask(String nodeId, String taskId, JSONObject contextVars, JSONObject sessionData) {
        logger.info("开始任务：taskId="+taskId);
    }

    @Override
    public void beforeNode(String nodeId, String taskId, JSONObject contextVars, JSONObject sessionData) {
        logger.info("开始执行节点："+nodeId+",taskId="+taskId);


    }

    @Override
    public void beforeControl(String nodeId, String taskId, DeviceData deviceData, JSONObject contextVars, JSONObject sessionData) {
        logger.info("开始执行控制节点："+nodeId+",taskId="+taskId+",command="+JSONObject.toJSONString(deviceData));
        contextVars.put("Sn","wwww");
        contextVars.put("Oc",1);
    }

    @Override
    public void processAuthNode(String nodeId, String taskId, HttpResp resp, JSONObject contextVars, JSONObject sessionData) {
        logger.info("处理鉴权节点："+nodeId+",taskId="+taskId+",resp="+resp.getRespBody());
        systemFunction.putCache(taskId,"aa","vvvv");
        if("getKey".equals(nodeId)) {
            JSONObject res = JSONObject.parseObject(resp.getRespBody());
            sessionData.put("ForeignKey", res.getString("rows"));
        }
        if("getToken".equals(nodeId)) {
            JSONObject res = JSONObject.parseObject(resp.getRespBody());
            sessionData.put("apiToken", res.getJSONObject("data").getString("apiToken"));
        }
    }

    @Override
    public void processNormalNode(String nodeId, String taskId, HttpResp resp, JSONObject contextVars, JSONObject sessionData) {
        logger.info("处理普通节点："+nodeId+",taskId="+taskId+",resp="+resp.getRespBody());
        systemFunction.getCache(taskId,"aa");
        DeviceData deviceData = new DeviceData();
        systemFunction.saveData(deviceData);
    }
    @Override
    public void processControlNode(String nodeId, String taskId, HttpResp resp, JSONObject contextVars, JSONObject sessionData) {
        logger.info("处理控制节点："+nodeId+",taskId="+taskId+",resp="+resp.getRespBody());

    }

    @Override
    public boolean processListLoopNode(String nodeId, String taskId, Object listItem, HttpResp resp, JSONObject contextVars, JSONObject sessionData) {
        logger.info("处理列表节点："+nodeId+",taskId="+taskId+",resp="+resp.getRespBody());
        return true;
    }

    @Override
    public boolean processSelfLoopNode(String nodeId, String taskId, HttpResp resp, JSONObject contextVars, JSONObject sessionData) {
        logger.info("处理循环节点："+nodeId+",taskId="+taskId+",resp="+resp.getRespBody());
        return false;
    }

    @Override
    public String computeSign(String source, JSONObject contextVars) {
        logger.info("source="+source);
        return MD5.getMd5String(source).toUpperCase();
    }

    @Override
    public void setSystemFunction(SystemFunction systemFunction) {
            this.systemFunction = systemFunction;
    }
}
